/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.core.fluid.forge.imitator;

import com.google.common.base.MoreObjects;
import com.google.common.base.Suppliers;
import dev.architectury.core.fluid.ArchitecturyFluidAttributes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraftforge.fluids.FluidType;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import org.jetbrains.annotations.NotNull;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;

public abstract class ArchitecturyFlowingFluid extends ForgeFlowingFluid {
    private static final Map<ArchitecturyFluidAttributes, FluidType> FLUID_TYPE_MAP = new IdentityHashMap<>();
    private final ArchitecturyFluidAttributes attributes;
    
    ArchitecturyFlowingFluid(ArchitecturyFluidAttributes attributes) {
        super(toForgeProperties(attributes));
        this.attributes = attributes;
    }
    
    private static Properties toForgeProperties(ArchitecturyFluidAttributes attributes) {
        Properties forge = new Properties(Suppliers.memoize(() -> {
            return FLUID_TYPE_MAP.computeIfAbsent(attributes, attr -> {
                return new ArchitecturyFluidAttributesForge(FluidType.Properties.create(), attr.getSourceFluid(), attr);
            });
        }), attributes::getSourceFluid, attributes::getFlowingFluid);
        forge.slopeFindDistance(attributes.getSlopeFindDistance());
        forge.levelDecreasePerBlock(attributes.getDropOff());
        forge.bucket(() -> MoreObjects.firstNonNull(attributes.getBucketItem(), Items.f_41852_));
        forge.tickRate(attributes.getTickDelay());
        forge.explosionResistance(attributes.getExplosionResistance());
        forge.block(() -> MoreObjects.firstNonNull(attributes.getBlock(), (LiquidBlock) Blocks.f_49990_));
        return forge;
    }
    
    @Override
    public Fluid m_5615_() {
        return attributes.getFlowingFluid();
    }
    
    @Override
    public Fluid m_5613_() {
        return attributes.getSourceFluid();
    }
    
    @Override
    protected boolean m_6760_(Level level) {
        return attributes.canConvertToSource();
    }
    
    @Override
    protected void m_7456_(LevelAccessor level, BlockPos pos, BlockState state) {
        // Same implementation as in WaterFluid.
        BlockEntity blockEntity = state.m_155947_() ? level.m_7702_(pos) : null;
        Block.m_49892_(state, level, pos, blockEntity);
    }
    
    @Override
    protected int m_6719_(LevelReader level) {
        return attributes.getSlopeFindDistance(level);
    }
    
    @Override
    protected int m_6713_(LevelReader level) {
        return attributes.getDropOff(level);
    }
    
    @Override
    public Item m_6859_() {
        Item item = attributes.getBucketItem();
        return item == null ? Items.f_41852_ : item;
    }
    
    @Override
    protected boolean m_5486_(FluidState state, BlockGetter level, BlockPos pos, Fluid fluid, Direction direction) {
        // Same implementation as in WaterFluid.
        return direction == Direction.DOWN && !this.m_6212_(fluid);
    }
    
    @Override
    public int m_6718_(LevelReader level) {
        return attributes.getTickDelay(level);
    }
    
    @Override
    protected float m_6752_() {
        return attributes.getExplosionResistance();
    }
    
    @Override
    protected BlockState m_5804_(FluidState state) {
        LiquidBlock block = attributes.getBlock();
        if (block == null) return Blocks.f_50016_.m_49966_();
        return block.m_49966_().m_61124_(LiquidBlock.f_54688_, m_76092_(state));
    }
    
    @NotNull
    @Override
    public Optional<SoundEvent> m_142520_() {
        return Optional.ofNullable(attributes.getFillSound());
    }
    
    @Override
    public boolean m_6212_(Fluid fluid) {
        return fluid == m_5613_() || fluid == m_5615_();
    }
    
    public static class Source extends ArchitecturyFlowingFluid {
        public Source(ArchitecturyFluidAttributes attributes) {
            super(attributes);
        }
        
        @Override
        public int m_7430_(FluidState state) {
            return 8;
        }
        
        @Override
        public boolean m_7444_(FluidState state) {
            return true;
        }
    }
    
    public static class Flowing extends ArchitecturyFlowingFluid {
        public Flowing(ArchitecturyFluidAttributes attributes) {
            super(attributes);
            this.m_76142_(this.m_76144_().m_61090_().m_61124_(f_75948_, 7));
        }
        
        @Override
        protected void m_7180_(StateDefinition.Builder<Fluid, FluidState> builder) {
            super.m_7180_(builder);
            builder.m_61104_(f_75948_);
        }
        
        @Override
        public int m_7430_(FluidState state) {
            return state.m_61143_(f_75948_);
        }
        
        @Override
        public boolean m_7444_(FluidState state) {
            return false;
        }
    }
}
