package com.shiroha.mmdskin.renderer.vmc;

import com.shiroha.mmdskin.NativeFunc;
import com.shiroha.mmdskin.config.ConfigManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class VmcLiveMotionBridge {
    private static final Logger logger = LogManager.getLogger();
    private static final VmcLiveMotionBridge INSTANCE = new VmcLiveMotionBridge();

    private static final String BIND_ADDRESS = System.getProperty("mmdskin.vmc.bind", "0.0.0.0");
    private static final long STALE_TIMEOUT_MS = Long.getLong("mmdskin.vmc.timeoutMs", 1000L);

    private static final int RECORD_SIZE = 32;
    private static final int FLAG_CLEAR_EXISTING = 1;
    private static final int FLAG_APPLY_ROTATION = 1 << 2;

    private static final Map<String, List<String>> VMC_TO_MMD_CANDIDATES = createBoneCandidates();

    private final AtomicBoolean receiverStarted = new AtomicBoolean(false);
    private final AtomicBoolean jniAvailable = new AtomicBoolean(true);
    private final Object receiverLock = new Object();
    private final AtomicReference<Map<String, BonePose>> snapshot = new AtomicReference<>(Collections.emptyMap());
    private final AtomicLong lastPacketTime = new AtomicLong(0L);
    private final Map<String, BonePose> writingBuffer = new HashMap<>();
    private final ConcurrentHashMap<Long, ModelBinding> modelBindings = new ConcurrentHashMap<>();
    private volatile DatagramSocket receiverSocket;
    private volatile int activePort = -1;

    private VmcLiveMotionBridge() {}

    public static VmcLiveMotionBridge getInstance() {
        return INSTANCE;
    }

    public void applyToModel(LivingEntity entity,
                             long modelHandle,
                             String modelName,
                             NativeFunc nativeFunc,
                             boolean blockByStage) {
        if (entity == null || nativeFunc == null || modelHandle == 0L) {
            return;
        }
        if (!jniAvailable.get()) {
            return;
        }
        if (!ConfigManager.isVmcEnabled()) {
            stopReceiver();
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }
        if (blockByStage) {
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }
        if (!(entity instanceof AbstractClientPlayer player)) {
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || !minecraft.player.getUUID().equals(player.getUUID())) {
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }

        ensureReceiverStarted(ConfigManager.getVmcPort());

        long elapsed = System.currentTimeMillis() - lastPacketTime.get();
        Map<String, BonePose> frame = snapshot.get();
        if (frame.isEmpty() || elapsed > STALE_TIMEOUT_MS) {
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }

        ModelBinding binding = modelBindings.computeIfAbsent(modelHandle,
                key -> createBinding(modelHandle, modelName, nativeFunc));
        if (binding.vmcToBoneIndex.isEmpty()) {
            return;
        }

        int count = encodeOverrides(binding, frame);
        if (count <= 0) {
            clearModelOverrides(modelHandle, nativeFunc);
            return;
        }

        try {
            nativeFunc.SetExternalBoneOverrides(modelHandle, binding.overrideBuffer, count,
                    FLAG_CLEAR_EXISTING | FLAG_APPLY_ROTATION);
        } catch (UnsatisfiedLinkError e) {
            disableJniBridge(e);
            return;
        }
        binding.hasActiveOverrides = true;
    }

    public void onModelDisposed(long modelHandle, NativeFunc nativeFunc) {
        if (modelHandle == 0L || nativeFunc == null) {
            return;
        }
        ModelBinding binding = modelBindings.remove(modelHandle);
        if (binding != null && binding.hasActiveOverrides) {
            try {
                nativeFunc.ClearExternalBoneOverrides(modelHandle);
            } catch (UnsatisfiedLinkError e) {
                disableJniBridge(e);
            }
        }
    }

    public void onConfigUpdated() {
        if (!jniAvailable.get()) {
            return;
        }
        if (!ConfigManager.isVmcEnabled()) {
            stopReceiver();
            return;
        }
        ensureReceiverStarted(ConfigManager.getVmcPort());
    }

    private void ensureReceiverStarted(int port) {
        synchronized (receiverLock) {
            if (receiverStarted.get() && activePort == port) {
                return;
            }
            if (receiverSocket != null) {
                receiverSocket.close();
                receiverSocket = null;
            }
            receiverStarted.set(false);
            activePort = port;
            if (!receiverStarted.compareAndSet(false, true)) {
                return;
            }
            Thread thread = new Thread(() -> runReceiver(port), "VMC-Receiver");
            thread.setDaemon(true);
            thread.start();
        }
    }

    private void stopReceiver() {
        synchronized (receiverLock) {
            receiverStarted.set(false);
            activePort = -1;
            if (receiverSocket != null) {
                receiverSocket.close();
                receiverSocket = null;
            }
        }
    }

    private void runReceiver(int port) {
        DatagramSocket socket = null;
        try {
            InetAddress bindAddress = "0.0.0.0".equals(BIND_ADDRESS) ? null : InetAddress.getByName(BIND_ADDRESS);
            socket = bindAddress == null
                    ? new DatagramSocket(port)
                    : new DatagramSocket(port, bindAddress);

            synchronized (receiverLock) {
                if (!receiverStarted.get() || activePort != port) {
                    socket.close();
                    return;
                }
                receiverSocket = socket;
            }

            logger.info("VMC live receiver started on {}:{}", BIND_ADDRESS, port);

            byte[] packetBuffer = new byte[65536];
            DatagramPacket packet = new DatagramPacket(packetBuffer, packetBuffer.length);

            while (receiverStarted.get() && activePort == port) {
                try {
                    packet.setLength(packetBuffer.length);
                    socket.receive(packet);
                    lastPacketTime.set(System.currentTimeMillis());
                    processOscPacket(packetBuffer, packet.getLength());
                    commitSnapshot();
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            logger.warn("VMC live receiver failed to start: {}", e.getMessage());
        } finally {
            if (socket != null) {
                socket.close();
            }
            synchronized (receiverLock) {
                if (receiverSocket == socket) {
                    receiverSocket = null;
                }
                if (activePort == port) {
                    receiverStarted.set(false);
                    activePort = -1;
                }
            }
        }
    }

    private void processOscPacket(byte[] data, int length) {
        if (length < 8) {
            return;
        }
        if (startsWith(data, 0, "#bundle")) {
            processBundleRecursive(data, 0, length);
        } else {
            processOscMessage(data, 0, length);
        }
    }

    private void processBundleRecursive(byte[] data, int offset, int length) {
        if (offset + 16 > offset + length) {
            return;
        }
        int pos = offset + 16;
        int end = offset + length;
        while (pos + 4 <= end) {
            int size = readInt(data, pos);
            pos += 4;
            if (size <= 0 || pos + size > end) {
                break;
            }
            if (startsWith(data, pos, "#bundle")) {
                processBundleRecursive(data, pos, size);
            } else {
                processOscMessage(data, pos, size);
            }
            pos += size;
        }
    }

    private void processOscMessage(byte[] data, int offset, int length) {
        int pos = offset;
        int end = offset + length;

        String address = readString(data, pos, end);
        if (address == null) {
            return;
        }
        pos += paddedLength(address);

        String types = readString(data, pos, end);
        if (types == null || types.isEmpty() || types.charAt(0) != ',') {
            return;
        }
        pos += paddedLength(types);

        if (!"/VMC/Ext/Bone/Pos".equals(address)) {
            return;
        }

        String boneName = null;
        float[] values = new float[7];
        int valueCount = 0;

        for (int i = 1; i < types.length(); i++) {
            char t = types.charAt(i);
            if (t == 's') {
                String str = readString(data, pos, end);
                if (str == null) {
                    return;
                }
                boneName = str;
                pos += paddedLength(str);
            } else if (t == 'f') {
                if (pos + 4 > end) {
                    return;
                }
                float value = Float.intBitsToFloat(readInt(data, pos));
                if (valueCount < values.length) {
                    values[valueCount] = value;
                }
                valueCount++;
                pos += 4;
            } else if (t == 'i') {
                if (pos + 4 > end) {
                    return;
                }
                float value = readInt(data, pos);
                if (valueCount < values.length) {
                    values[valueCount] = value;
                }
                valueCount++;
                pos += 4;
            } else {
                return;
            }
        }

        if (boneName != null && valueCount >= 7) {
            writingBuffer.put(boneName,
                    new BonePose(values[0], values[1], values[2], values[3], values[4], values[5], values[6]));
        }
    }

    private void commitSnapshot() {
        Map<String, BonePose> immutableCopy = new HashMap<>(writingBuffer.size());
        immutableCopy.putAll(writingBuffer);
        snapshot.set(Collections.unmodifiableMap(immutableCopy));
    }

    private ModelBinding createBinding(long modelHandle, String modelName, NativeFunc nativeFunc) {
        LinkedHashMap<String, Integer> mapped = new LinkedHashMap<>();
        List<String> missing = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : VMC_TO_MMD_CANDIDATES.entrySet()) {
            String vmcBone = entry.getKey();
            int resolved = -1;
            for (String candidate : entry.getValue()) {
                int idx = findBoneIndex(nativeFunc, modelHandle, candidate);
                if (idx >= 0) {
                    resolved = idx;
                    break;
                }
            }
            if (resolved >= 0) {
                mapped.put(vmcBone, resolved);
            } else {
                missing.add(vmcBone);
            }
        }

        if (!mapped.isEmpty()) {
            logger.info("VMC mapping ready: model='{}', mapped={}, missing={}", modelName, mapped.size(), missing.size());
        } else {
            logger.warn("VMC mapping failed: model='{}', no compatible bones found", modelName);
        }

        ByteBuffer buffer = ByteBuffer.allocateDirect(Math.max(mapped.size(), 1) * RECORD_SIZE).order(ByteOrder.LITTLE_ENDIAN);
        return new ModelBinding(mapped, buffer);
    }

    private int encodeOverrides(ModelBinding binding, Map<String, BonePose> frame) {
        ByteBuffer buffer = binding.overrideBuffer;
        buffer.clear();

        int count = 0;
        for (Map.Entry<String, Integer> entry : binding.vmcToBoneIndex.entrySet()) {
            BonePose pose = frame.get(entry.getKey());
            if (pose == null) {
                continue;
            }

            float[] quat = new float[]{pose.qx, pose.qy, -pose.qz, -pose.qw};
            if (!normalizeQuaternionInPlace(quat)) {
                quat[0] = 0.0f;
                quat[1] = 0.0f;
                quat[2] = 0.0f;
                quat[3] = 1.0f;
            }

            float qx = quat[0];
            float qy = quat[1];
            float qz = quat[2];
            float qw = quat[3];

            int boneIndex = entry.getValue();
            float[] previous = binding.previousQuaternion.get(boneIndex);
            if (previous != null) {
                float dot = qx * previous[0] + qy * previous[1] + qz * previous[2] + qw * previous[3];
                if (dot < 0.0f) {
                    qx = -qx;
                    qy = -qy;
                    qz = -qz;
                    qw = -qw;
                }
            }
            binding.previousQuaternion.put(boneIndex, new float[]{qx, qy, qz, qw});

            buffer.putInt(boneIndex);
            buffer.putFloat(0.0f);
            buffer.putFloat(0.0f);
            buffer.putFloat(0.0f);
            buffer.putFloat(qx);
            buffer.putFloat(qy);
            buffer.putFloat(qz);
            buffer.putFloat(qw);
            count++;
        }

        buffer.flip();
        return count;
    }

    private static boolean normalizeQuaternionInPlace(float[] q) {
        float lenSq = q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3];
        if (!Float.isFinite(lenSq) || lenSq <= 1.0e-8f) {
            return false;
        }
        float invLen = (float) (1.0 / Math.sqrt(lenSq));
        q[0] *= invLen;
        q[1] *= invLen;
        q[2] *= invLen;
        q[3] *= invLen;
        return true;
    }

    private void clearModelOverrides(long modelHandle, NativeFunc nativeFunc) {
        ModelBinding binding = modelBindings.get(modelHandle);
        if (binding == null || !binding.hasActiveOverrides) {
            return;
        }
        try {
            nativeFunc.ClearExternalBoneOverrides(modelHandle);
        } catch (UnsatisfiedLinkError e) {
            disableJniBridge(e);
            return;
        }
        binding.hasActiveOverrides = false;
        binding.previousQuaternion.clear();
    }

    private int findBoneIndex(NativeFunc nativeFunc, long modelHandle, String candidate) {
        try {
            return nativeFunc.FindBoneIndexByName(modelHandle, candidate);
        } catch (UnsatisfiedLinkError e) {
            disableJniBridge(e);
            return -1;
        }
    }

    private void disableJniBridge(UnsatisfiedLinkError error) {
        if (jniAvailable.compareAndSet(true, false)) {
            stopReceiver();
            logger.warn("VMC bridge disabled: native overrides are unavailable ({})", error.getMessage());
        }
    }

    private static Map<String, List<String>> createBoneCandidates() {
        LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
        map.put("Hips", List.of("下半身", "腰", "Center", "center", "hips", "Hips"));
        map.put("Spine", List.of("上半身", "spine", "Spine"));
        map.put("Chest", List.of("上半身2", "胸", "chest", "Chest"));
        map.put("UpperChest", List.of("上半身2", "上半身3", "upper_chest", "UpperChest"));
        map.put("Neck", List.of("首", "neck", "Neck"));
        map.put("Head", List.of("頭", "head", "Head", "あたま"));

        map.put("LeftShoulder", List.of("左肩", "left_shoulder", "LeftShoulder"));
        map.put("LeftUpperArm", List.of("左腕", "left_arm", "LeftArm"));
        map.put("LeftLowerArm", List.of("左ひじ", "left_elbow", "LeftElbow", "LeftLowerArm"));
        map.put("LeftHand", List.of("左手首", "left_wrist", "LeftHand", "LeftWrist"));

        map.put("RightShoulder", List.of("右肩", "right_shoulder", "RightShoulder"));
        map.put("RightUpperArm", List.of("右腕", "right_arm", "RightArm"));
        map.put("RightLowerArm", List.of("右ひじ", "right_elbow", "RightElbow", "RightLowerArm"));
        map.put("RightHand", List.of("右手首", "right_wrist", "RightHand", "RightWrist"));

        map.put("LeftUpperLeg", List.of("左足", "left_leg", "LeftUpperLeg", "LeftUpLeg"));
        map.put("LeftLowerLeg", List.of("左ひざ", "left_knee", "LeftLowerLeg", "LeftLeg"));
        map.put("LeftFoot", List.of("左足首", "left_ankle", "LeftFoot"));
        map.put("LeftToes", List.of("左つま先", "left_toe", "LeftToes"));

        map.put("RightUpperLeg", List.of("右足", "right_leg", "RightUpperLeg", "RightUpLeg"));
        map.put("RightLowerLeg", List.of("右ひざ", "right_knee", "RightLowerLeg", "RightLeg"));
        map.put("RightFoot", List.of("右足首", "right_ankle", "RightFoot"));
        map.put("RightToes", List.of("右つま先", "right_toe", "RightToes"));

        map.put("LeftEye", List.of("左目", "LeftEye", "eye_L", "Eye_L", "eye.L", "Eye.L"));
        map.put("RightEye", List.of("右目", "RightEye", "eye_R", "Eye_R", "eye.R", "Eye.R"));
        return Collections.unmodifiableMap(map);
    }

    private static boolean startsWith(byte[] data, int offset, String prefix) {
        byte[] bytes = prefix.getBytes(StandardCharsets.US_ASCII);
        if (offset < 0 || offset + bytes.length > data.length) {
            return false;
        }
        for (int i = 0; i < bytes.length; i++) {
            if (data[offset + i] != bytes[i]) {
                return false;
            }
        }
        return true;
    }

    private static int readInt(byte[] data, int offset) {
        return ((data[offset] & 0xFF) << 24)
                | ((data[offset + 1] & 0xFF) << 16)
                | ((data[offset + 2] & 0xFF) << 8)
                | (data[offset + 3] & 0xFF);
    }

    private static String readString(byte[] data, int offset, int end) {
        if (offset < 0 || offset >= end) {
            return null;
        }
        int length = 0;
        while (offset + length < end && data[offset + length] != 0) {
            length++;
        }
        if (offset + length >= end) {
            return null;
        }
        return new String(data, offset, length, StandardCharsets.US_ASCII);
    }

    private static int paddedLength(String value) {
        int len = value.getBytes(StandardCharsets.US_ASCII).length + 1;
        return len + ((4 - (len % 4)) & 3);
    }

    private static final class BonePose {
        private final float px;
        private final float py;
        private final float pz;
        private final float qx;
        private final float qy;
        private final float qz;
        private final float qw;

        private BonePose(float px, float py, float pz, float qx, float qy, float qz, float qw) {
            this.px = px;
            this.py = py;
            this.pz = pz;
            this.qx = qx;
            this.qy = qy;
            this.qz = qz;
            this.qw = qw;
        }
    }

    private static final class ModelBinding {
        private final LinkedHashMap<String, Integer> vmcToBoneIndex;
        private final ByteBuffer overrideBuffer;
        private final Map<Integer, float[]> previousQuaternion = new HashMap<>();
        private volatile boolean hasActiveOverrides;

        private ModelBinding(LinkedHashMap<String, Integer> vmcToBoneIndex, ByteBuffer overrideBuffer) {
            this.vmcToBoneIndex = vmcToBoneIndex;
            this.overrideBuffer = overrideBuffer;
            this.hasActiveOverrides = false;
        }
    }
}
